# 🦀 Anime Game CLI

WIP

## Roadmap to 1.0.0

- Game installation
  - Installation info (current + latest, needs update or not)
  - Install the game (calculate installation difference)
  - Update existing installation
  - Repair game files
- Voice packages
  - Installed, available and need to be updated or not
  - Update outdated package
  - Repair broken packages
- Wine
  - Download / Delete
  - Create prefix
- DXVK
  - Download / Delete
  - Apply
- Patch
  - Status (current, latest, needs to be applied, ...)
  - Apply patch
- Run the game
  - Additional features (todo)
